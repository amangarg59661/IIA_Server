package com.astro.dto.workflow.InventoryModule.GiDto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class SaveGiDto {

    private String gprnNo;
    private String giNo;
    private String inspectionNo;
    private String installationDate;
    private String commissioningDate;
    private String locationId;
    private BigDecimal gprnAmount;
    private BigDecimal poAmount;
    private List<GiMaterialDtlDto> materialDtlList;

    /**
     * The ID of the user submitting this request.
     * Matches IndentCreation.createdBy (Integer) for access control comparison.
     */
    private Integer createdBy;

    /**
     * The role of the user submitting this request.
     * Expected values: "store person" or "indentor"
     * Used alongside createdBy to enforce GPRN access rules on the backend.
     */
    private String role;
}
