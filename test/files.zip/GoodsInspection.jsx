import { Card, message } from "antd";
import React, { useCallback, useEffect, useRef, useState } from "react";
import Heading from "../../../components/DKG_Heading";
import CustomForm from "../../../components/DKG_CustomForm";
import { renderFormFields } from "../../../utils/CommonFunctions";
import ButtonContainer from "../../../components/ButtonContainer";
import { useReactToPrint } from "react-to-print";
import axios from "axios";
import { useSelector } from "react-redux";
import CustomModal from "../../../components/CustomModal";
import { useLocation } from "react-router-dom";
import GprnSearchDropdown from "../../../components/GprnSearchDropdown";

const GoodsInspection = () => {
  const printRef = useRef();
  const handlePrint = useReactToPrint({ content: () => printRef.current });

  const location = useLocation();
  const processNo = location?.state?.processNo || null;

  // userId is Integer — matches IndentCreation.createdBy for backend access check
  const { userId, role } = useSelector((state) => state.auth);

  const [modalOpen, setModalOpen] = useState(false);
  const [submitBtnLoading, setSubmitBtnLoading] = useState(false);
  const [formData, setFormData] = useState({
    gprnNo: processNo || "",
    materialDtlList: [],
  });

  // ---------------------------------------------------------------------------
  // Form field change handler
  // ---------------------------------------------------------------------------
  const handleChange = (fieldName, value) => {
    if (typeof fieldName === "string") {
      setFormData((prev) => ({ ...prev, [fieldName]: value }));
    } else {
      setFormData((prev) => {
        const list = [...prev.materialDtlList];

        if (fieldName[2] === "acceptedQuantity") {
          const accepted = parseFloat(value);
          const rejected =
            parseFloat(list[fieldName[1]].receivedQuantity) - accepted;

          if (
            rejected + accepted !==
            parseFloat(list[fieldName[1]].receivedQuantity)
          ) {
            message.error(
              "Total accepted quantity must be equal to received quantity."
            );
            list[fieldName[1]].acceptedQuantity = 0;
            list[fieldName[1]].rejectedQuantity = 0;
            list[fieldName[1]].rejectReason = "";
            return { ...prev, materialDtlList: list };
          }

          list[fieldName[1]].acceptedQuantity = accepted;
          list[fieldName[1]].rejectedQuantity = rejected;
          if (rejected <= 0) {
            list[fieldName[1]].rejectReason = "";
          }
          return { ...prev, materialDtlList: list };
        }

        list[fieldName[1]][fieldName[2]] = value;
        return { ...prev, materialDtlList: list };
      });
    }
  };

  // ---------------------------------------------------------------------------
  // Data merge helper — combines GI details and GPRN details into one flat object
  // ---------------------------------------------------------------------------
  const mergeData = (giDtls = {}, gprnDtls = {}) => ({
    inspectionNo: giDtls.inspectionNo || "",
    gprnNo: gprnDtls.processId || giDtls.gprnNo || "",
    installationDate: giDtls.installationDate || "",
    commissioningDate: giDtls.commissioningDate || "",
    materialDtlList: giDtls.materialDtlList || [],
    date: gprnDtls.date || "",
    challanNo: gprnDtls.challanNo || "",
    vendorId: gprnDtls.vendorId || "",
    vendorEmail: gprnDtls.vendorEmail || "",
    vendorName: gprnDtls.vendorName || "",
    vendorContact: gprnDtls.vendorContact || "",
    fieldStation: gprnDtls.fieldStation || "",
    indentorName: gprnDtls.indentorName || "",
    locationId: gprnDtls.locationId || giDtls.locationId || "",
    deliveryDate: gprnDtls.deliveryDate || "",
    supplyExpectedDate: gprnDtls.supplyExpectedDate || "",
    poId: gprnDtls.poId || "",
    consigneeDetail: gprnDtls.consigneeDetail || "",
  });

  // ---------------------------------------------------------------------------
  // Search — fetches either a GI record (edit mode) or a GPRN record (create mode)
  // ---------------------------------------------------------------------------
  const handleSearch = useCallback(async (value, isGprnSearch) => {
    if (!value) {
      message.warning("Please enter a valid value.");
      return;
    }

    try {
      if (!isGprnSearch) {
        // Edit mode: load existing GI
        const { data } = await axios.get(
          `/api/process-controller/getSubProcessDtls?processStage=GI&processNo=${value}`
        );
        const merged = mergeData(
          data?.responseData?.giDtls,
          data?.responseData?.gprnDtls
        );
        merged.giNo = data?.responseData?.giDtls?.inspectionNo || "";
        setFormData(merged);
      } else {
        // Create mode: load GPRN details
        const { data } = await axios.get(
          `/api/process-controller/getSubProcessDtls?processStage=GPRN&processNo=${value}`
        );
        setFormData({
          ...data?.responseData,
          gprnNo: data?.responseData?.processId,
        });
      }
    } catch (error) {
      message.error(
        error?.response?.data?.responseStatus?.message ||
          "Error fetching data."
      );
    }
  }, []);

  // ---------------------------------------------------------------------------
  // Submit — create or update
  // ---------------------------------------------------------------------------
  const onFinish = async () => {
    // role is included so the backend can enforce access control server-side
    const payload = { ...formData, createdBy: userId, role };

    try {
      setSubmitBtnLoading(true);
      const isUpdate = !!formData.giNo;
      const apiUrl = isUpdate
        ? "/api/process-controller/updateGi"
        : "/api/process-controller/saveGi";

      const { data } = await axios.post(apiUrl, payload);

      setFormData((prev) => ({
        ...prev,
        giNo: data?.responseData?.processNo,
      }));

      localStorage.removeItem("goodsInspectionDraft");

      if (isUpdate) {
        message.success("Updated successfully.");
      } else {
        setModalOpen(true);
      }
    } catch (error) {
      message.error(
        error?.response?.data?.responseStatus?.message ||
          "Failed to save Goods Inspection."
      );
    } finally {
      setSubmitBtnLoading(false);
    }
  };

  // ---------------------------------------------------------------------------
  // Form field definitions
  // ---------------------------------------------------------------------------
  const generalDtls = [
    {
      heading: "Order Details",
      colCnt: 5,
      fieldList: [
        {
          name: "gprnNo",
          label: "GPRN No",
          required: true,
          span: 2,
          type: "custom",
          render: () => (
            <GprnSearchDropdown
              label="GPRN No"
              value={formData.gprnNo}
              // userId and role are forwarded so the dropdown fetches
              // only GPRNs this user is permitted to inspect
              userId={userId}
              role={role}
              onChange={(val) => {
                handleChange("gprnNo", val);
                handleSearch(val, true);
              }}
            />
          ),
        },
        {
          name: "poId",
          label: "PO Id.",
          type: "text",
          disabled: true,
        },
        {
          name: "giNo",
          label: "GI No.",
          span: 2,
          type: "search",
          onSearch: () => handleSearch(formData.giNo, false),
        },
        {
          name: "date",
          label: "Date",
          type: "date",
          required: true,
        },
        {
          name: "installationDate",
          label: "Installation Date",
          type: "date",
        },
        {
          name: "commissioningDate",
          label: "Commission Date",
          type: "date",
        },
      ],
    },
    {
      heading: "Vendor Details",
      colCnt: 4,
      fieldList: [
        { name: "vendorId",      label: "Vendor ID",      type: "text", span: 2, required: true },
        { name: "vendorName",    label: "Vendor Name",    type: "text", span: 2, required: true },
        { name: "vendorEmail",   label: "Vendor Email",   type: "text", span: 2, required: true },
        { name: "vendorContact", label: "Vendor Contact", type: "text", span: 2, required: true },
      ],
    },
    {
      heading: "Delivery & Invoice Details",
      colCnt: 5,
      fieldList: [
        { name: "challanNo",          label: "Challan/Invoice No.", type: "text", required: true, span: 2 },
        { name: "deliveryDate",       label: "Delivery Date",       type: "date", required: true, span: 1 },
        { name: "supplyExpectedDate", label: "Date of Supply",      type: "date", required: true, span: 1 },
        { name: "fieldStation",       label: "Field Station",       type: "text", required: true, span: 2 },
        { name: "indentorName",       label: "Indentor Name",       type: "text", required: true, span: 2 },
        { name: "gprnAmount",         label: "GPRN Amount",         type: "text", span: 2 },
        { name: "poAmount",           label: "PO Amount",           type: "text", span: 2 },
      ],
    },
    {
      heading: "Material Details",
      name: "materialDtlList",
      colCnt: 4,
      children: [
        { name: "materialCode", label: "Material Code",        type: "text", span: 2, required: true },
        { name: "materialDesc", label: "Material Description", type: "text", span: 3, required: true },
        { name: "uomId",        label: "UOM",                  type: "text", span: 1, required: true },
        { name: "receivedQuantity", label: "Received Quantity", type: "text", disabled: true, required: true },
        { name: "acceptedQuantity", label: "Accepted Quantity", type: "text", required: true },
        { name: "rejectedQuantity", label: "Rejected Quantity", type: "text", disabled: true, required: true },
        ...(formData.materialDtlList?.some((item) => parseFloat(item.rejectedQuantity) > 0)
          ? [
              {
                name: "rejectionType",
                label: "Rejection Type",
                type: "select",
                span: 2,
                required: true,
                options: [
                  { label: "Permanent",    value: "permanent" },
                  { label: "Replacement",  value: "replacement" },
                ],
              },
              {
                name: "rejectReason",
                label: "Reason for Rejection",
                type: "text",
                span: 2,
                required: true,
              },
            ]
          : []),
        {
          name: "installationReportBase64",
          label: "Installation Report",
          type: "image",
          span: 2,
        },
      ],
    },
    {
      heading: "Consignee & Warranty Information",
      colCnt: 3,
      fieldList: [
        { name: "consigneeDetail", label: "Consignee Details", type: "text", required: true, span: 2 },
      ],
    },
  ];

  // ---------------------------------------------------------------------------
  // Effects
  // ---------------------------------------------------------------------------

  // Restore draft on mount
  useEffect(() => {
    const draft = localStorage.getItem("goodsInspectionDraft");
    if (draft) {
      setFormData(JSON.parse(draft));
      message.success("Form loaded from draft.");
    }
  }, []);

  // Auto-load GI when navigated to with a processNo (e.g. from a list view)
  useEffect(() => {
    if (processNo) {
      handleSearch(processNo, false);
    }
  }, [processNo, handleSearch]);

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------
  return (
    <Card className="a4-container" ref={printRef}>
      <Heading title="Goods Inspection" />
      <CustomForm formData={formData} onFinish={onFinish}>
        {renderFormFields(generalDtls, handleChange, formData, "", null, setFormData, handleSearch)}
        <ButtonContainer
          onFinish={onFinish}
          formData={formData}
          draftDataName="goodsInspectionDraft"
          submitBtnLoading={submitBtnLoading}
          submitBtnEnabled
          printBtnEnabled
          draftBtnEnabled
          handlePrint={handlePrint}
        />
      </CustomForm>
      <CustomModal
        isOpen={modalOpen}
        setIsOpen={setModalOpen}
        title="Goods Inspection"
        processNo={formData?.giNo}
      />
    </Card>
  );
};

export default GoodsInspection;
