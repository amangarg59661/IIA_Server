package com.astro.service.impl.InventoryModule;

import com.astro.dto.workflow.InventoryModule.GprnDropdownDto;
import com.astro.dto.workflow.InventoryModule.GprnPoVendorDto;
import com.astro.dto.workflow.NewAssetResponseDto;
import com.astro.entity.UserMaster;
import com.astro.repository.InventoryModule.GprnRepository.GprnMasterRepository;
import com.astro.repository.InventoryModule.GprnRepository.GprnMaterialDtlRepository;
import com.astro.repository.InventoryModule.isn.IssueNoteMasterRepository;
import com.astro.repository.InventoryModule.ogp.OgpMasterRejectedGiRepository;
import com.astro.repository.ProcurementModule.IndentCreation.MaterialDetailsRepository;
import com.astro.repository.ProcurementModule.PurchaseOrder.PurchaseOrderAttributesRepository;
import com.astro.repository.UserMasterRepository;
import com.astro.util.EmailService;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.math.BigDecimal;
import java.util.stream.Collectors;

import com.astro.service.InventoryModule.GiService;
import com.astro.service.InventoryModule.GprnService;
import com.astro.repository.InventoryModule.GiRepository.*;
import com.astro.repository.MaterialMasterRepository;
import com.astro.repository.InventoryModule.AssetMasterRepository;
import com.astro.repository.InventoryModule.GoodsInspectionConsumableDetailRepository;
import com.astro.entity.MaterialMaster;
import com.astro.entity.InventoryModule.*;
import com.astro.entity.ProcurementModule.PurchaseOrderAttributes;
import com.astro.dto.workflow.InventoryModule.GiDto.*;
import com.astro.dto.workflow.InventoryModule.GprnDto.SaveGprnDto;
import com.astro.dto.workflow.InventoryModule.gprn.GprnPendingInspectionDetailDto;
import com.astro.dto.workflow.InventoryModule.gprn.GprnPendingInspectionDto;
import com.astro.exception.*;
import com.astro.constant.AppConstant;
import com.astro.util.CommonUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.modelmapper.ModelMapper;

@Service
public class GiServiceImpl implements GiService {

    @Value("${filePath}")
    private String bp;

    @Autowired
    private GiMasterRepository gimr;

    @Autowired
    private GiMaterialDtlRepository gimdr;

    @Autowired
    private GprnService gprnService;

    @Autowired
    private AssetMasterRepository amr;

    @Autowired
    private MaterialMasterRepository mmr;

    @Autowired
    private IssueNoteMasterRepository issueNoteMasterRepository;

    @Autowired
    private GoodsInspectionConsumableDetailRepository gicdr;

    @Autowired
    private GiWorkflowStatusRepository gistausRepo;

    @Autowired
    private PurchaseOrderAttributesRepository poar;

    @Autowired
    private GprnMasterRepository gprnMasterRepository;

    @Autowired
    private GprnMaterialDtlRepository gprnMaterialDtlRepository;

    @Autowired
    private OgpMasterRejectedGiRepository ogpMasterRejectedGiRepository;

    @Autowired
    private MaterialDetailsRepository materialDetailsRepository;

    @Autowired
    private UserMasterRepository userMasterRepository;

    @Autowired
    private EmailService emailService;

    private final String basePath;

    public GiServiceImpl(@Value("${filePath}") String bp) {
        this.basePath = bp + "/INV";
    }

    // =========================================================================
    // SAVE
    // =========================================================================

    @Override
    @Transactional
    public String saveGi(SaveGiDto req) {
        gprnService.validateGprnSubProcessId(req.getGprnNo());

        // --- Access enforcement ---
        // Reject the request if the submitting user is not authorised for this GPRN.
        // This mirrors the frontend dropdown filter and cannot be bypassed.
        GprnMasterEntity gprnForCheck = gprnMasterRepository.findBySubProcessId(
                Integer.parseInt(req.getGprnNo().split("/")[1]));
        if (gprnForCheck != null && !isGprnAccessibleToUser(gprnForCheck, req.getCreatedBy(), req.getRole())) {
            throw new BusinessException(new ErrorDetails(
                    AppConstant.ERROR_CODE_RESOURCE,
                    AppConstant.ERROR_TYPE_CODE_RESOURCE,
                    AppConstant.ERROR_TYPE_RESOURCE,
                    "You are not authorised to create a Goods Inspection for this GPRN."));
        }

        SaveGprnDto gprnDto = gprnService.getGprnDtls(req.getGprnNo());

        ModelMapper mapper = new ModelMapper();
        GiMasterEntity gime = new GiMasterEntity();
        gime.setCommissioningDate(CommonUtils.convertStringToDateObject(req.getCommissioningDate()));
        gime.setInstallationDate(CommonUtils.convertStringToDateObject(req.getCommissioningDate()));
        gime.setGprnProcessId(req.getGprnNo().split("/")[0].substring(3));
        gime.setGprnSubProcessId(Integer.parseInt(req.getGprnNo().split("/")[1]));
        gime.setCreateDate(LocalDateTime.now());
        gime.setCreatedBy(req.getCreatedBy());
        gime.setLocationId(req.getLocationId());
        gime.setStatus("AWAITING APPROVAL");
        gime.setGprnAmount(req.getGprnAmount());
        gime.setPoAmount(req.getPoAmount());

        gime = gimr.save(gime);

        List<GiMaterialDtlEntity> gimdeList = new ArrayList<>();
        List<GoodsInspectionConsumableDetailEntity> gicdeList = new ArrayList<>();
        StringBuilder errorMessage = new StringBuilder();
        boolean errorFound = false;

        for (GiMaterialDtlDto gmdd : req.getMaterialDtlList()) {

            if (gmdd.getCategory().equalsIgnoreCase("consumable")) {

                Optional<GoodsInspectionConsumableDetailEntity> gicdeOpt = gicdr
                        .findByGprnSubProcessIdAndMaterialCode(
                                Integer.parseInt(req.getGprnNo().split("/")[1]),
                                gmdd.getMaterialCode());

                if (gicdeOpt.isPresent()) {
                    errorMessage.append("Inspection already done for GPRN No. ")
                            .append(req.getGprnNo())
                            .append(" and Material Code ").append(gmdd.getMaterialCode());
                    errorFound = true;
                    continue;
                }

                if (gmdd.getReceivedQuantity()
                        .compareTo(gmdd.getAcceptedQuantity().add(gmdd.getRejectedQuantity())) != 0) {
                    errorMessage.append("Total received quantity for ").append(gmdd.getMaterialCode())
                            .append(" is not equal to accepted + rejected quantity.");
                    errorFound = true;
                    continue;
                }

                GoodsInspectionConsumableDetailEntity gicde = new GoodsInspectionConsumableDetailEntity();
                mapper.map(gmdd, gicde);
                gicde.setInspectionSubProcessId(gime.getInspectionSubProcessId());
                gicde.setGprnSubProcessId(Integer.parseInt(req.getGprnNo().split("/")[1]));
                gicde.setGprnProcessId(Integer.parseInt(req.getGprnNo().split("/")[0].substring(3)));

                try {
                    gicde.setInstallationReportFilename(
                            CommonUtils.saveBase64Image(gmdd.getInstallationReportBase64(), basePath));
                } catch (Exception e) {
                    // non-fatal: file save failure is logged but does not abort the transaction
                }

                gicdeList.add(gicde);

            } else {

                Optional<GiMaterialDtlEntity> gimdeOpt = gimdr.findByGprnSubProcessIdAndMaterialCode(
                        Integer.parseInt(req.getGprnNo().split("/")[1]),
                        gmdd.getMaterialCode());

                if (gimdeOpt.isPresent()) {
                    errorMessage.append("Inspection already done for GPRN No. ")
                            .append(req.getGprnNo())
                            .append(" and Material Code ").append(gmdd.getMaterialCode());
                    errorFound = true;
                    continue;
                }

                if (gmdd.getReceivedQuantity()
                        .compareTo(gmdd.getAcceptedQuantity().add(gmdd.getRejectedQuantity())) != 0) {
                    errorMessage.append("Total received quantity for ").append(gmdd.getMaterialCode())
                            .append(" is not equal to accepted + rejected quantity.");
                    errorFound = true;
                    continue;
                }

                MaterialMaster materialMaster = mmr.findById(gmdd.getMaterialCode()).orElse(null);
                boolean shouldCreateAsset = materialMaster != null
                        && Boolean.TRUE.equals(materialMaster.getAssetFlag())
                        && gmdd.getAcceptedQuantity().compareTo(BigDecimal.ZERO) > 0;

                String instlRepFileName = null;
                try {
                    instlRepFileName = CommonUtils.saveBase64Image(gmdd.getInstallationReportBase64(), basePath);
                } catch (Exception e) {
                    // non-fatal
                }

                if (shouldCreateAsset) {
                    int qty = gmdd.getAcceptedQuantity().intValue();
                    for (int i = 0; i < qty; i++) {
                        NewAssetResponseDto asset = createNewAsset(gmdd, req.getCreatedBy(),
                                gprnDto.getPoId(), gprnDto.getLocationId());

                        GiMaterialDtlEntity gimde = new GiMaterialDtlEntity();
                        mapper.map(gmdd, gimde);
                        gimde.setAcceptedQuantity(BigDecimal.ONE);
                        gimde.setAssetId(asset.getAssetId());
                        gimde.setAssetCode(asset.getAssetCode());
                        gimde.setInspectionSubProcessId(gime.getInspectionSubProcessId());
                        gimde.setGprnSubProcessId(Integer.parseInt(req.getGprnNo().split("/")[1]));
                        gimde.setGprnProcessId(Integer.parseInt(req.getGprnNo().split("/")[0].substring(3)));
                        gimde.setInstallationReportFileName(instlRepFileName);
                        gimdeList.add(gimde);
                    }
                } else {
                    GiMaterialDtlEntity gimde = new GiMaterialDtlEntity();
                    mapper.map(gmdd, gimde);
                    gimde.setInspectionSubProcessId(gime.getInspectionSubProcessId());
                    gimde.setGprnSubProcessId(Integer.parseInt(req.getGprnNo().split("/")[1]));
                    gimde.setGprnProcessId(Integer.parseInt(req.getGprnNo().split("/")[0].substring(3)));
                    gimde.setInstallationReportFileName(instlRepFileName);
                    gimdeList.add(gimde);
                }
            }
        }

        if (errorFound) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    errorMessage.toString()));
        }

        gimdr.saveAll(gimdeList);
        gicdr.saveAll(gicdeList);

        GiWorkflowStatus workflowStatus = new GiWorkflowStatus();
        workflowStatus.setProcessId("INV" + gime.getGprnProcessId());
        workflowStatus.setSubProcessId(gime.getInspectionSubProcessId());
        workflowStatus.setAction("Created");
        workflowStatus.setRemarks("GI Created");
        workflowStatus.setCreatedBy(req.getCreatedBy());
        workflowStatus.setCreateDate(LocalDateTime.now());
        gistausRepo.save(workflowStatus);

        return "INV" + gime.getGprnProcessId() + "/" + gime.getInspectionSubProcessId();
    }

    // =========================================================================
    // UPDATE
    // =========================================================================

    @Override
    @Transactional
    public String updateGi(SaveGiDto req) {
        String[] processNoSplit = req.getGprnNo().split("/");
        if (processNoSplit.length != 2) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    "Invalid process number format"));
        }

        // --- Access enforcement ---
        GprnMasterEntity gprnForCheck = gprnMasterRepository.findBySubProcessId(
                Integer.parseInt(processNoSplit[1]));
        if (gprnForCheck != null && !isGprnAccessibleToUser(gprnForCheck, req.getCreatedBy(), req.getRole())) {
            throw new BusinessException(new ErrorDetails(
                    AppConstant.ERROR_CODE_RESOURCE,
                    AppConstant.ERROR_TYPE_CODE_RESOURCE,
                    AppConstant.ERROR_TYPE_RESOURCE,
                    "You are not authorised to update a Goods Inspection for this GPRN."));
        }

        Integer subProcessId = Integer.parseInt(processNoSplit[1]);
        GiMasterEntity gime = gimr.findByGprnSubProcessId(subProcessId)
                .orElseThrow(() -> new InvalidInputException(new ErrorDetails(
                        AppConstant.ERROR_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_RESOURCE,
                        "GI Master not found for the given GPRN No.")));

        gime.setCommissioningDate(CommonUtils.convertStringToDateObject(req.getCommissioningDate()));
        gime.setInstallationDate(CommonUtils.convertStringToDateObject(req.getInstallationDate()));
        gime.setLocationId(req.getLocationId());
        gime.setStatus("AWAITING APPROVAL");
        gimr.save(gime);

        ModelMapper mapper = new ModelMapper();
        StringBuilder errorMessage = new StringBuilder();
        boolean errorFound = false;

        for (GiMaterialDtlDto gmdd : req.getMaterialDtlList()) {

            Optional<GoodsInspectionConsumableDetailEntity> gicdeOpt = gicdr
                    .findByGprnSubProcessIdAndMaterialCode(subProcessId, gmdd.getMaterialCode());

            if (gicdeOpt.isPresent()) {
                GoodsInspectionConsumableDetailEntity gicde = gicdeOpt.get();
                mapper.map(gmdd, gicde);

                if (!gmdd.getReceivedQuantity()
                        .equals(gmdd.getAcceptedQuantity().add(gmdd.getRejectedQuantity()))) {
                    errorMessage.append("Received quantity mismatch for ").append(gmdd.getMaterialCode()).append(". ");
                    errorFound = true;
                    continue;
                }

                try {
                    gicde.setInstallationReportFilename(
                            CommonUtils.saveBase64Image(gmdd.getInstallationReportBase64(), basePath));
                } catch (Exception e) {
                    // non-fatal
                }
                gicdr.save(gicde);
                continue;
            }

            Optional<GiMaterialDtlEntity> gimdeOpt = gimdr
                    .findByGprnSubProcessIdAndMaterialCode(subProcessId, gmdd.getMaterialCode());

            if (gimdeOpt.isPresent()) {
                GiMaterialDtlEntity gimde = gimdeOpt.get();
                mapper.map(gmdd, gimde);

                if (!gmdd.getReceivedQuantity()
                        .equals(gmdd.getAcceptedQuantity().add(gmdd.getRejectedQuantity()))) {
                    errorMessage.append("Received quantity mismatch for ").append(gmdd.getMaterialCode()).append(". ");
                    errorFound = true;
                    continue;
                }

                if (gmdd.getAcceptedQuantity().compareTo(BigDecimal.ZERO) > 0 && gimde.getAssetId() == null) {
                    SaveGprnDto gprnDto = gprnService.getGprnDtls(req.getGprnNo());
                    NewAssetResponseDto asset = createNewAsset(gmdd, req.getCreatedBy(),
                            gprnDto.getPoId(), gprnDto.getLocationId());
                    gimde.setAssetCode(asset.getAssetCode());
                    gimde.setAssetId(asset.getAssetId());
                }

                try {
                    gimde.setInstallationReportFileName(
                            CommonUtils.saveBase64Image(gmdd.getInstallationReportBase64(), basePath));
                } catch (Exception e) {
                    // non-fatal
                }
                gimdr.save(gimde);
                continue;
            }

            errorMessage.append("Material Code ").append(gmdd.getMaterialCode())
                    .append(" not found in GI tables. ");
            errorFound = true;
        }

        if (errorFound) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    errorMessage.toString()));
        }

        GiWorkflowStatus workflowStatus = new GiWorkflowStatus();
        workflowStatus.setProcessId("INV" + gime.getGprnProcessId());
        workflowStatus.setSubProcessId(gime.getInspectionSubProcessId());
        workflowStatus.setAction("UPDATED");
        workflowStatus.setRemarks("GI updated");
        workflowStatus.setCreatedBy(req.getCreatedBy());
        workflowStatus.setCreateDate(LocalDateTime.now());
        gistausRepo.save(workflowStatus);

        return "INV" + gime.getGprnProcessId() + "/" + gime.getInspectionSubProcessId();
    }

    // =========================================================================
    // READ
    // =========================================================================

    @Override
    public Map<String, Object> getGiDtls(String processNo) {
        ModelMapper mapper = new ModelMapper();
        String[] processNoSplit = processNo.split("/");

        if (processNoSplit.length != 2) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    "Invalid process ID"));
        }

        Integer inspectionId = Integer.parseInt(processNoSplit[1]);
        GiMasterEntity gime = gimr.findById(inspectionId)
                .orElseThrow(() -> new InvalidInputException(new ErrorDetails(
                        AppConstant.ERROR_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_RESOURCE,
                        "Goods Inspection not found for the provided process ID.")));

        List<GiMaterialDtlEntity> gimdeList = gimdr.findByInspectionSubProcessId(gime.getInspectionSubProcessId());
        List<GoodsInspectionConsumableDetailEntity> gicdeList = gicdr
                .findByInspectionSubProcessId(gime.getInspectionSubProcessId());

        List<GiMaterialDtlDto> consumableDtos = gicdeList.stream()
                .map(gicde -> {
                    GiMaterialDtlDto gmdd = mapper.map(gicde, GiMaterialDtlDto.class);
                    try {
                        gmdd.setInstallationReportBase64(
                                CommonUtils.convertImageToBase64(gicde.getInstallationReportFilename(), basePath));
                        gmdd.setInstallationReportFileName(gicde.getInstallationReportFilename());
                    } catch (Exception e) {
                        // non-fatal
                    }
                    return gmdd;
                }).collect(Collectors.toList());

        List<GiMaterialDtlDto> nonConsumableDtos = gimdeList.stream()
                .map(gimde -> {
                    GiMaterialDtlDto gmdd = mapper.map(gimde, GiMaterialDtlDto.class);
                    gmdd.setAssetId(gimde.getAssetId());
                    gmdd.setRejectReason(gimde.getRejectReason());
                    gmdd.setAssetCode(gimde.getAssetCode());
                    gmdd.setInstallationReportFileName(gimde.getInstallationReportFileName());
                    amr.findById(gimde.getAssetId()).ifPresent(asset -> {
                        gmdd.setAssetDesc(asset.getAssetDesc());
                        gmdd.setUomId(asset.getUomId());
                    });
                    try {
                        gmdd.setInstallationReportBase64(
                                CommonUtils.convertImageToBase64(gimde.getInstallationReportFileName(), basePath));
                    } catch (Exception e) {
                        // non-fatal
                    }
                    return gmdd;
                }).collect(Collectors.toList());

        consumableDtos.addAll(nonConsumableDtos);

        SaveGiDto giRes = new SaveGiDto();
        giRes.setInspectionNo(processNo);
        giRes.setGprnNo(processNo);
        giRes.setInstallationDate(CommonUtils.convertDateToString(gime.getInstallationDate()));
        giRes.setCommissioningDate(CommonUtils.convertDateToString(gime.getCommissioningDate()));
        giRes.setGprnAmount(gime.getGprnAmount());
        giRes.setPoAmount(gime.getPoAmount());
        giRes.setMaterialDtlList(consumableDtos);

        Map<String, Object> combinedRes = new HashMap<>();
        combinedRes.put("giDtls", giRes);
        combinedRes.put("gprnDtls",
                gprnService.getGprnDtls(processNo.split("/")[0] + "/" + gime.getGprnSubProcessId()));
        return combinedRes;
    }

    public List<GprnPendingInspectionDto> getGiStatusWise(String status, Optional<String> createdBy) {
        List<Object[]> results = createdBy.isPresent()
                ? gimr.getGiStatusWiseAndCreatedBy(status, createdBy.get())
                : gimr.getGiStatusWise(status);

        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        return results.stream().map(row -> {
            GprnPendingInspectionDto dto = new GprnPendingInspectionDto();
            dto.setProcessId((String) row[0]);
            dto.setSubProcessId((Integer) row[1]);
            dto.setPoId((String) row[2]);
            dto.setLocationId((String) row[3]);
            dto.setDate(CommonUtils.convertSqlDateToString((java.sql.Date) row[4]));
            dto.setChallanNo((String) row[5]);
            dto.setDeliveryDate(CommonUtils.convertSqlDateToString((java.sql.Date) row[6]));
            dto.setVendorId((String) row[7]);
            dto.setFieldStation((String) row[8]);
            dto.setIndentorName((String) row[9]);
            dto.setSupplyExpectedDate(CommonUtils.convertSqlDateToString((java.sql.Date) row[10]));
            dto.setConsigneeDetail((String) row[11]);
            dto.setWarrantyYears((BigDecimal) row[12]);
            dto.setProject((String) row[13]);
            dto.setReceivedBy((String) row[14]);

            try {
                String detailsJson = (String) row[15];
                if (detailsJson != null && !detailsJson.isEmpty()) {
                    dto.setMaterialDetails(mapper.readValue(
                            detailsJson,
                            mapper.getTypeFactory().constructCollectionType(
                                    List.class, GprnPendingInspectionDetailDto.class)));
                } else {
                    dto.setMaterialDetails(new ArrayList<>());
                }
            } catch (Exception e) {
                dto.setMaterialDetails(new ArrayList<>());
            }

            dto.setStatus((String) row[16]);
            return dto;
        }).collect(Collectors.toList());
    }

    public List<GiWorkflowStatusDto> getGiHistoryByProcessId(String processId, Integer subProcessId) {
        return gistausRepo.findByProcessIdAndSubProcessIdOrderByIdAsc(processId, subProcessId)
                .stream()
                .map(status -> {
                    GiWorkflowStatusDto dto = new GiWorkflowStatusDto();
                    dto.setProcessId(status.getProcessId());
                    dto.setSubProcessId(status.getSubProcessId());
                    dto.setAction(status.getAction());
                    dto.setRemarks(status.getRemarks());
                    dto.setCreatedBy(status.getCreatedBy());
                    dto.setCreateDate(status.getCreateDate());
                    return dto;
                }).toList();
    }

    public List<GiMasterEntity> getGiByStatuses() {
        return gimr.findByStatusIn(Collections.singletonList("AWAITING APPROVAL"));
    }

    public List<GiMasterEntity> getGiByIndentorStatuses() {
        return gimr.findByStatusIn(Arrays.asList("REJECTED", "CHANGE REQUEST"));
    }

    // =========================================================================
    // APPROVAL WORKFLOW
    // =========================================================================

    @Override
    @Transactional
    public void approveGi(GiApprovalDto req) {
        updateGiStatusAndRemarks(req);
        updatePoBasedonRejectionType(req);
        giMailSender(req.getProcessNo());
    }

    @Override
    @Transactional
    public void rejectGi(GiApprovalDto req) {
        updateGiStatusAndRemarks(req);
        giMailSender(req.getProcessNo());
    }

    @Override
    @Transactional
    public void changeReqGi(GiApprovalDto req) {
        updateGiStatusAndRemarks(req);
        giMailSender(req.getProcessNo());
    }

    private void updateGiStatusAndRemarks(GiApprovalDto req) {
        String[] processNoSplit = req.getProcessNo().split("/");
        if (processNoSplit.length != 2) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    "Invalid process number format"));
        }

        Integer inspectionId = Integer.parseInt(processNoSplit[1]);
        GiMasterEntity giMaster = gimr.findById(inspectionId)
                .orElseThrow(() -> new InvalidInputException(new ErrorDetails(
                        AppConstant.ERROR_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_RESOURCE,
                        "Goods Inspection not found")));

        giMaster.setStatus(req.getStatus());
        gimr.save(giMaster);

        GiWorkflowStatus history = new GiWorkflowStatus();
        history.setProcessId(processNoSplit[0]);
        history.setSubProcessId(inspectionId);
        history.setAction(req.getStatus());
        history.setRemarks(req.getRemarks());
        history.setCreatedBy(req.getCreatedBy());
        history.setCreateDate(LocalDateTime.now());
        gistausRepo.save(history);
    }

    public String giMailSender(String processNumber) {
        try {
            Integer inspectionSubProcessId = Integer.parseInt(processNumber.split("/")[1]);

            GiMasterEntity giMaster = gimr.findById(inspectionSubProcessId)
                    .orElseThrow(() -> new BusinessException(new ErrorDetails(
                            AppConstant.ERROR_CODE_RESOURCE,
                            AppConstant.ERROR_TYPE_CODE_RESOURCE,
                            AppConstant.ERROR_TYPE_RESOURCE,
                            "GI not found")));

            GprnMasterEntity gprnMaster = gprnMasterRepository.findById(giMaster.getGprnSubProcessId())
                    .orElseThrow(() -> new BusinessException(new ErrorDetails(
                            AppConstant.ERROR_CODE_RESOURCE,
                            AppConstant.ERROR_TYPE_CODE_RESOURCE,
                            AppConstant.ERROR_TYPE_RESOURCE,
                            "GPRN not found")));

            UserMaster um = userMasterRepository.findByUserId(Integer.valueOf(gprnMaster.getReceivedBy()));
            emailService.sendGiMails(
                    um.getEmail(),
                    um.getUserName(),
                    Integer.valueOf(gprnMaster.getReceivedBy()),
                    String.valueOf(giMaster.getInspectionSubProcessId()),
                    giMaster.getGprnProcessId(),
                    giMaster.getStatus());

        } catch (Exception e) {
            return "Failed to send GI mail: " + e.getMessage();
        }
        return "";
    }

    private void updatePoBasedonRejectionType(GiApprovalDto req) {
        String[] processNoSplit = req.getProcessNo().split("/");
        String poId = "PO" + processNoSplit[0].substring(3);
        Integer inspectionId = Integer.parseInt(processNoSplit[1]);

        List<GiMaterialDtlEntity> gimdeList = gimdr.findByInspectionSubProcessId(inspectionId);
        List<GoodsInspectionConsumableDetailEntity> gicdeList = gicdr.findByInspectionSubProcessId(inspectionId);

        for (GiMaterialDtlEntity gimde : gimdeList) {
            if ("replacement".equalsIgnoreCase(gimde.getRejectionType())) {
                PurchaseOrderAttributes poa = poar
                        .findByPurchaseOrder_PoIdAndMaterialCode(poId, gimde.getMaterialCode())
                        .orElseThrow(() -> new BusinessException(new ErrorDetails(
                                AppConstant.ERROR_CODE_RESOURCE,
                                AppConstant.ERROR_TYPE_CODE_RESOURCE,
                                AppConstant.ERROR_TYPE_RESOURCE,
                                "Purchase Order not found")));
                BigDecimal received = poa.getReceivedQuantity() != null ? poa.getReceivedQuantity() : BigDecimal.ZERO;
                BigDecimal rejected = gimde.getRejectedQuantity() != null ? gimde.getRejectedQuantity() : BigDecimal.ZERO;
                poa.setReceivedQuantity(received.subtract(rejected));
                poar.save(poa);
            }
        }

        for (GoodsInspectionConsumableDetailEntity gicde : gicdeList) {
            if ("replacement".equalsIgnoreCase(gicde.getRejectionType())) {
                PurchaseOrderAttributes poa = poar
                        .findByPurchaseOrder_PoIdAndMaterialCode(poId, gicde.getMaterialCode())
                        .orElseThrow(() -> new BusinessException(new ErrorDetails(
                                AppConstant.ERROR_CODE_RESOURCE,
                                AppConstant.ERROR_TYPE_CODE_RESOURCE,
                                AppConstant.ERROR_TYPE_RESOURCE,
                                "Purchase Order not found")));
                BigDecimal received = poa.getReceivedQuantity() != null ? poa.getReceivedQuantity() : BigDecimal.ZERO;
                BigDecimal rejected = gicde.getRejectedQuantity() != null ? gicde.getRejectedQuantity() : BigDecimal.ZERO;
                poa.setReceivedQuantity(received.subtract(rejected));
                poar.save(poa);
            }
        }
    }

    // =========================================================================
    // VALIDATION
    // =========================================================================

    @Override
    public void validateGiIsApproved(String processNo) {
        String[] parts = processNo.split("/");
        if (parts.length != 2) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    "Invalid GI No."));
        }
        GiMasterEntity giMaster = gimr
                .findByGprnProcessIdAndInspectionSubProcessId(parts[0].substring(3), Integer.parseInt(parts[1]))
                .orElseThrow(() -> new BusinessException(new ErrorDetails(
                        AppConstant.ERROR_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_RESOURCE,
                        "Provided GI No. is not valid.")));

        if (!"APPROVED".equalsIgnoreCase(giMaster.getStatus())) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    "GI is not approved. Cannot create GRN."));
        }
    }

    @Override
    public void validateGiSubProcessId(String processNo) {
        String[] parts = processNo.split("/");
        if (parts.length != 2) {
            throw new InvalidInputException(new ErrorDetails(
                    AppConstant.USER_INVALID_INPUT,
                    AppConstant.ERROR_TYPE_CODE_VALIDATION,
                    AppConstant.ERROR_TYPE_VALIDATION,
                    "Invalid GI No."));
        }
        if (!gimr.existsById(Integer.parseInt(parts[1]))) {
            throw new BusinessException(new ErrorDetails(
                    AppConstant.ERROR_CODE_RESOURCE,
                    AppConstant.ERROR_TYPE_CODE_RESOURCE,
                    AppConstant.ERROR_TYPE_RESOURCE,
                    "Provided GI No. is not valid."));
        }
    }

    // =========================================================================
    // DROPDOWN — GPRN access control
    // =========================================================================

    /**
     * Returns pending GRNs the given user is permitted to inspect.
     *
     * Access rules (driven by indent count on the tender, not role alone):
     *   Store person → master access, sees every pending GPRN.
     *   Indentor      → sees only GPRNs whose tender has exactly 1 indent
     *                   AND that indent was created by this user.
     */
    public List<GprnDropdownDto> getPendingGprnsForGI(Integer userId, String role) {
        return gprnMasterRepository.findPendingGprnsWithMaterial()
                .stream()
                .filter(gprn -> isGprnAccessibleToUser(gprn, userId, role))
                .map(g -> new GprnDropdownDto(
                        g.getSubProcessId(),
                        "INV" + g.getProcessId() + "/" + g.getSubProcessId(),
                        g.getPoId(),
                        g.getVendorId(),
                        gprnMaterialDtlRepository.findMaterialDescriptionsBySubProcessId(g.getSubProcessId())))
                .collect(Collectors.toList());
    }

    /**
     * Central access gate used by both the dropdown filter and saveGi / updateGi.
     *
     * Traversal:  GPRN.poId → PurchaseOrder.tenderId → IndentId (join table) → IndentCreation.createdBy
     *
     *   Store person role → always true (master access, single or multi-indent)
     *   Indentor role:
     *     indent count = 1 AND IndentCreation.createdBy == userId → true
     *     indent count > 1 → false (only store person may handle multi-indent tenders)
     *     indent count = 0 → false (data integrity issue; deny by default)
     */
    public boolean isGprnAccessibleToUser(GprnMasterEntity gprn, Integer userId, String role) {
        if ("store person".equalsIgnoreCase(role)) {
            return true;
        }

        String poId = gprn.getPoId();
        if (poId == null) {
            return false;
        }

        String tenderId = gprnMasterRepository.findTenderIdByPoId(poId);
        if (tenderId == null) {
            return false;
        }

        int indentCount = gprnMasterRepository.countIndentsByTenderId(tenderId);

        if (indentCount == 1) {
            Integer indentorUserId = gprnMasterRepository.findSingleIndentCreatedByForTender(tenderId);
            return userId != null && userId.equals(indentorUserId);
        }

        // indentCount == 0 or > 1: indentor has no access
        return false;
    }

    // =========================================================================
    // REJECTED GI DROPDOWN
    // =========================================================================

    public List<GprnDropdownDto> getPendingRejectedGis() {
        List<GiMaterialDtlEntity> normalEntities = new ArrayList<>();
        normalEntities.addAll(gimdr.findByRejectionType("replacement"));
        normalEntities.addAll(gimdr.findByRejectionType("permanent"));

        List<GprnDropdownDto> normalGis = normalEntities.stream()
                .filter(gi -> !ogpMasterRejectedGiRepository.existsByGiId(
                        "INV" + gi.getGprnProcessId() + "/" + gi.getInspectionSubProcessId()))
                .map(gi -> {
                    GprnPoVendorDto gprnDto = gprnMasterRepository
                            .findPoIdAndVendorIdBySubProcessId(gi.getGprnSubProcessId());
                    return new GprnDropdownDto(
                            gi.getInspectionSubProcessId(),
                            "INV" + gi.getGprnProcessId() + "/" + gi.getInspectionSubProcessId(),
                            gprnDto.getPoId(),
                            gprnDto.getVendorId(),
                            gimdr.findMaterialDescriptionsByInspectionSubProcessId(gi.getInspectionSubProcessId()));
                }).collect(Collectors.toList());

        List<GoodsInspectionConsumableDetailEntity> consumableEntities = new ArrayList<>();
        consumableEntities.addAll(gicdr.findByRejectionType("replacement"));
        consumableEntities.addAll(gicdr.findByRejectionType("permanent"));

        List<GprnDropdownDto> consumableGis = consumableEntities.stream()
                .filter(gi -> !ogpMasterRejectedGiRepository.existsByGiId(
                        "INV" + gi.getGprnProcessId() + "/" + gi.getInspectionSubProcessId()))
                .map(gi -> {
                    GprnPoVendorDto gprnDto = gprnMasterRepository
                            .findPoIdAndVendorIdBySubProcessId(gi.getGprnSubProcessId());
                    return new GprnDropdownDto(
                            gi.getInspectionSubProcessId(),
                            "INV" + gi.getGprnProcessId() + "/" + gi.getInspectionSubProcessId(),
                            gprnDto.getPoId(),
                            gprnDto.getVendorId(),
                            gicdr.findMaterialDescriptionsByInspectionSubProcessId(gi.getInspectionSubProcessId()));
                }).collect(Collectors.toList());

        normalGis.addAll(consumableGis);
        return normalGis;
    }

    // =========================================================================
    // ASSET HELPERS
    // =========================================================================

    private NewAssetResponseDto createNewAsset(GiMaterialDtlDto materialDtl, Integer createdBy,
                                               String poId, String locationId) {
        MaterialMaster mme = mmr.findById(materialDtl.getMaterialCode())
                .orElseThrow(() -> new InvalidInputException(new ErrorDetails(
                        AppConstant.ERROR_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_CODE_RESOURCE,
                        AppConstant.ERROR_TYPE_RESOURCE,
                        "Material not found for the provided material code.")));

        AssetMasterEntity ame = new ModelMapper().map(materialDtl, AssetMasterEntity.class);
        ame.setAssetDesc(materialDtl.getMaterialDesc());
        ame.setCreateDate(LocalDateTime.now());
        ame.setCreatedBy(createdBy);
        ame.setUpdatedDate(LocalDateTime.now());
        ame.setUnitPrice(mme.getUnitPrice());
        ame.setPoId(poId);
        ame.setAssetCode(generateAssetCode(locationId, mme.getSubCategory().substring(0, 3)));

        amr.save(ame);
        return new NewAssetResponseDto(ame.getAssetId(), ame.getAssetCode());
    }

    private String generateAssetCode(String fieldStation, String subCategory) {
        String prefix = (fieldStation + subCategory + getFinancialYear() + "-").toUpperCase();
        Integer maxAssetId = amr.findMaxAssetId();
        int nextSeq = maxAssetId != null ? maxAssetId + 1 : 1;
        return prefix + String.format("%03d", nextSeq);
    }

    private String getFinancialYear() {
        LocalDate today = LocalDate.now();
        int startYear = today.getMonthValue() >= 4 ? today.getYear() % 100 : (today.getYear() - 1) % 100;
        int endYear = (startYear + 1) % 100;
        return String.format("%02d%02d", startYear, endYear);
    }
}
